﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CBnip.Items.Add("01")
        CBnip.Items.Add("02")
        CBnip.Items.Add("03")
        CBnip.Items.Add("04")

        CBgol.Items.Add("1A")
        CBgol.Items.Add("1B")
        CBgol.Items.Add("1C")
        CBgol.Items.Add("1D")

        CBjabatan.Items.Add("staff")
        CBjabatan.Items.Add("helper")
        CBjabatan.Items.Add("sales")


    End Sub

    Private Sub CBnip_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBnip.SelectedIndexChanged
        Select Case CBnip.Text
            Case "01"
                Tnama.Text = "devid"
            Case "02"
                Tnama.Text = "ronald"
            Case "03"
                Tnama.Text = "irnaldika"
            Case "04"
                Tnama.Text = "oswald"
            Case Else
                Tnama.Text = ""
        End Select
    End Sub

    Private Sub CBgol_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBgol.SelectedIndexChanged
        Select Case CBgol.Text
            Case "1A"
                Tgaji.Text = 4000000
            Case "1B"
                Tgaji.Text = 3000000
            Case "1C"
                Tgaji.Text = 2000000
            Case "1D"
                Tgaji.Text = 1000000
            Case Else
                Tgaji.Text = 0
        End Select
    End Sub

    Private Sub CBjabatan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CBjabatan.SelectedIndexChanged
        Select Case CBjabatan.Text
            Case "staff"
                Ttunjangan.Text = 1500000
            Case "helper"
                Ttunjangan.Text = 1000000
            Case "sales"
                Ttunjangan.Text = 1700000
            Case Else
                Ttunjangan.Text = 0
        End Select
    End Sub

    Private Sub Bhapus_Click(sender As Object, e As EventArgs) Handles Bhapus.Click
        CBnip.Text = ""
        Tnama.Text = ""
        CBgol.Text = ""
        Tgaji.Text = ""
        CBjabatan.Text = ""
        Ttunjangan.Text = ""
        Ttotal.Text = ""
    End Sub

    Private Sub Bproses_Click(sender As Object, e As EventArgs) Handles Bproses.Click
        Ttotal.Text = Val(Tgaji.Text) + Val(Ttunjangan.Text)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pesan As String
        pesan = MsgBox("Apakah anda ingin keluar", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Keluar")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub
End Class
